# App

[Github repo](https://github.com/ThibautDeMaerteleire/minifootball_app)<br/>
[Footy app](https://footy.thibautdemaerteleire.be/)<br/>
[Footy api](https://api.footy.thibautdemaerteleire.be/)